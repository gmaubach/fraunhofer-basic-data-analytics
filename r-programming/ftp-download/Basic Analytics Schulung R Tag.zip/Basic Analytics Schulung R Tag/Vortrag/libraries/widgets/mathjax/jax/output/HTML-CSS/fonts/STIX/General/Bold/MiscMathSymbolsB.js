/*
 *  /MathJax/jax/output/HTML-CSS/fonts/STIX/General/Bold/MiscMathSymbolsB.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["STIXGeneral-bold"],{10624:[705,200,675,105,570],10678:[634,130,864,50,814],10679:[634,130,864,50,814],10680:[634,130,864,50,814],10688:[634,130,864,50,814],10689:[634,130,864,50,814],10692:[661,158,910,45,865],10693:[661,158,910,45,865],10694:[661,158,910,45,865],10695:[661,158,910,45,865]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/General/Bold/MiscMathSymbolsB.js");

