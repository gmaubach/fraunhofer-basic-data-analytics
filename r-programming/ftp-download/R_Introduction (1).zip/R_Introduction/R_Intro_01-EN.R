###############################################################################################################
## o Filename: 
##  R_Intro_01-EN.R
## o Author: 
##  rroesler (01.03.2013)
## 
## o Description:
##
##
## o Versions:
##
## o Maturity:
##
## o Source command to use 
##   source('.../R_Intro_01-EN.R')
##
## o Last changed:
##
################################################################################################################
#
#

#-------------------------------------------------------
# R as a calculator
#-------------------------------------------------------

# interacting with the R-shell (R as a calculator)
4 + 4
4 + 5 /(2 * 2)
# testing of history

# first examples
# saving of values
a <- 4 + 4

# creating of objects (vectors, ...)
# function c(...) creates a vector 
b <- c(1,2,3,4,5,6,7,8,9,10)

# displaying objects
b

# ":" is used to create a sequence of numbers
b2 <- c(1:10)
b2

# combination of vectors
b3 <- c(c(1:5),6,c(7:10))
b3

# hash mark introduces a comment

#-------------------------------------------------------
# functions in R
#-------------------------------------------------------

mean(b)
sum(b2)
range(b3)

# how to get help with methods
?mean
?'<-'
?'+'

# define your own methods
myMean <- function(dataVector){
	num <- sum(dataVector)  # set numerator
	denom <- length(dataVector) # set denominator
	return(num/denom)
}

mean(b); myMean(b)

#-------------------------------------------------------
# libraries in R
#-------------------------------------------------------
# install.packages(pkgs = "twitteR", dependencies = TRUE)
# 
# library(twitteR)
# ??twitteR # R-search for topic "twitteR
# dsTweets <- searchTwitter('#Datascience', n=100)
# 
# length(dsTweets) # number of returned tweets 
# head(dsTweets, n = 10) # the first 10 tweets
# dsTweets
# dsTweets[[1]]$getScreenName()
# dsTweets[[1]]$getText()
# dsTweets[[1]]$getCreated()
# 
# hist(as.POSIXct(sapply(dsTweets, function(singleTweet){
# 			return(singleTweet$getCreated())
# 		}), origin="1970-01-01"), breaks = "hours", freq = TRUE, main = "Histogramm", xlab = "Uhrzeit")

install.packages(pkgs = "ggmap", dependencies = TRUE)

require(ggmap) # library(ggmap) - alternative

adress  <- "Schloss Birlinghoven, 53757 Sankt Augustin"
coords  <- geocode(adress, output = "more")

theme_set(theme_bw(16))
hdf     <- get_map(location = c(lon = mean(coords[,1]), lat = mean(coords[,2])), zoom = 11)
ggmap(hdf, extent = "normal") + geom_point(aes(x = lon, y = lat), size = 5, colour = "red", data = coords)


#-------------------------------------------------------
# Workspaces in R
#-------------------------------------------------------
setwd("C:/TMP/R_Workspace_Dir/")
a <- c(1:100)
save.image(file = "MyWorkspace.RData")
q() # quit and close console

# open new console
setwd("C:/TMP/R_Workspace_Dir/")
load(file = "MyWorkspace.RData")
ls()
a



