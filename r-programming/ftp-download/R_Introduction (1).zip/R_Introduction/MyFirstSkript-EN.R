###############################################################################################################
## o Filename: 
##  MyFirstSkript-EN.R
## o Author: 
##  rroesler (05.03.2013)
## 
## o Description:
##
##
## o Versions:
##
##
## o Source command to use 
##   source('.../MyFirstSkript-EN.R')
##
## o Last changed:
##
################################################################################################################
#
#

n <- 50
a1 <- runif(n, min=0, max=1) # draw 50 uniformly distributed random numbers between 0 and 1
a2 <- runif(n, min=0, max=1) # draw 50 uniformly distributed random numbers between 0 and 1

m1 <- mean(a1)
m2 <- mean(a2)

myComparison <- function(result1, result2){
	if(result1 > result2){
		return(result1)
	}else{
		return(result2)
	}
}

compareResult <- myComparison(result1 = m1, result2 = m2)