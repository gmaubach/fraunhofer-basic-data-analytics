
#Load Apple stock exchange rates from the Internet
appleStock <- read.table(
  "http://ichart.finance.yahoo.com/table.csv?s=AAPL&d=3&e=3&f=2008&g=d&a=8&b=7&c=1984&ignore=.cvs",
  header=TRUE,sep=",",na.strings="NA",dec=".")

# Check what we got back (structure of the data frame)
str(appleStock)

# Peek at the actual data
head(appleStock)

# Let's plot this
require(ggplot2)

# Unfortunately, importing the data has left the date (given as strings) to be treated as
# opaque factors, not as times, which however we need it to be in order to plot time series
# So, let's convert it
appleStock$Date <- as.Date(appleStock$Date, "%Y-%m-%d")

# Assemble the plot object
p <- ggplot(appleStock, aes(Date, colour=Notation)) +
  labs(title="Apple Stock Performance") +
#  geom_line(data = appleStock, aes(x=Date, y=Open, colour="Opening")) +
  geom_line(data = appleStock, aes(x=Date, y=Close, colour="Closing")) +
#  geom_line(data = appleStock, aes(x=Date, y=Open, colour="Opening")) +
  xlab('Date') +
  ylab('Apple Stock Price')

# And actually display it ;-)
p

p2 <- ggplot(appleStock, aes(Date)) +
  labs(title="Apple Stock Performance") +
  geom_ribbon(aes(ymin=Low, ymax=High, fill="darkgrey")) +
#  geom_line(aes(y=Open, colour="Opening")) +
#  geom_line(aes(y=Close, colour="Closing")) +
  xlab('Date') +
  ylab('Apple Stock Price')
p2