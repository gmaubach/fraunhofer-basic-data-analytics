###############################################################################################################
## o Filename: 
##  R_Intro_Part_02-EN.R
## o Author: 
##  rroesler (05.03.2013)
## 
## o Description:
##
##
## o Versions:
##
## o Maturity:
##
## o Source command to use 
##   source('.../R_Intro_Part_02-EN.R')
##
## o Last changed:
##
################################################################################################################
#
#

#-------------------------------------------------------
# data types in R
#-------------------------------------------------------
# vector with numeric values
aNum <- c(1:10)
aNum
str(aNum)
is.numeric(aNum)

# automatic type converting
aNum <- c(aNum, 2.2)
str(aNum)
is.numeric(aNum)

# vector with ordered values
aOrd <- factor(x = c("medium","small","large","large","medium","small"), 
		levels = c("small", "medium", "large"), 
		ordered = TRUE)
aOrd
str(aOrd)
aOrd[1] <- "something"
aOrd

# vector with nominal values
aNom <- factor(x = c("blue","red","yellow","yellow","yellow","red"))
aNom
str(aNom)

# date type
aDate <- as.POSIXct(c("2013-01-22 14:52:03","2013-03-19 12:00:01"), 
           format = "%Y-%m-%d %H:%M:%S")
aDate
str(aDate)

#-------------------------------------------------------
# data structures in R
#-------------------------------------------------------
# vectors
c(1:10)
c("a","b","a","a")

# lists
l1 <- list(
		e1 = c(1,2,3), e2 = c("a","b"), 
		e3 = function(i){return(i*i)}, 
		e4 = list(ee1 = c(1,2,3))
)
l1

# Matrix
matrix(c(1:16), nrow = 4)

# data.frame
data.frame(ID = c(1,2,3), 
		AGE= c(20,30,45), 
		SECTOR= c("IT","HEALTH","AUTOMOTIVE")
)

#-------------------------------------------------------
# selection of data
#-------------------------------------------------------

# selection is done by entering indices, column or line name within square brackets [lines,columns]
myVector <- c(1:20)

# selection in vectors
myVector[2] # second element
myVector[c(1,2)] # first and second element
myVector[seq(1,20,2)] # every second element
myVector[-1] # all except the first element
myVector[-c(1:10)] # all except the first 10 elements

# selection in data frames
myDF <- data.frame(ID = c(1,2,3,4,5), 
		AGE = c(20,30,45,30,25), 
		SECTOR = c("IT","HEALTH","AUTOMOTIVE","IT","IT")
)

# selection of individuals
myDF[c(1,2),]

# selection of features
myDF[,c(2,3)]
myDF[,c("AGE","SECTOR")]

#-------------------------------------------------------
# data import
#-------------------------------------------------------
# web data (http://brusdeylins.info/projects/yahoo-finance-api/)
appleStock <- read.table("http://ichart.finance.yahoo.com/table.csv?s=AAPL&d=3&e=3&f=2008&g=d&a=8&b=7&c=1984&ignore=.cvs",
		header=TRUE, sep=",", na.strings="NA", dec=".")
str(appleStock)
head(appleStock)

# Excel data
# install.packages("xlsx", dep=TRUE)
library(xlsx)
excelData <- read.xlsx(file = "DATA/MovieExampleWithMissing.xlsx", sheetIndex = 1)
head(excelData, n=4)
excelData$ANZAHL_AUSLEIHEN <- sample(1:5, nrow(excelData), replace = TRUE)
head(excelData, n=4)
write.xlsx(x = excelData, file = "DATA/MovieExampleWithMissing_RandomRating.xlsx", sheetName = "Test")

# data from other statistical packages
# Paket 'foreign'

# database import
# the packages 'RMySQL', 'ROracle', 'RPostgreSQL', 'RSQLite', 'RJDBC', 'RODBC', ... contain interfaces
# including writing capabilities

# file import (text, CSV, ...)
csvData <- read.csv2(file = "DATA/MovieExampleWithMissing.csv", na.strings = "")
head(csvData, n=4)
csvData$ANZAHL_AUSLEIHEN <- sample(1:5, nrow(csvData), replace = TRUE)
head(csvData, n=4)
write.csv2(x = csvData, file = "DATA/MovieExampleWithMissing_RandomRating.csv", row.names = FALSE)

#-------------------------------------------------------
# record overview
#-------------------------------------------------------
# record structure
str(csvData)

# the first n entries
head(csvData, n=5)

# distribution
summary(csvData)

# number of columns
ncol(csvData)

# number of lines
nrow(csvData)

#-------------------------------------------------------
# standardisation/ normalisation
#-------------------------------------------------------
# using 'scale'
scaledData <- data.frame(
		scale(csvData[,c("Age","ANZAHL_AUSLEIHEN")], center = TRUE, scale = TRUE), 
		csvData[,c("Gender","Likes_Movie")])
summary(scaledData)
sd(scaledData$Age, na.rm=TRUE)
sd(scaledData$ANZAHL_AUSLEIHEN, na.rm=TRUE)

# "by hand" normalisation 
scaledDatav2 <- csvData
scaledDatav2$Age <- (scaledDatav2$Age - mean(scaledDatav2$Age, na.rm=TRUE))/sd(scaledDatav2$Age, na.rm=TRUE)
scaledDatav2$ANZAHL_AUSLEIHEN <- (scaledDatav2$ANZAHL_AUSLEIHEN - mean(scaledDatav2$ANZAHL_AUSLEIHEN, na.rm=TRUE))/sd(scaledDatav2$ANZAHL_AUSLEIHEN, na.rm=TRUE)
summary(scaledDatav2)
sd(scaledDatav2$Age, na.rm=TRUE)
sd(scaledDatav2$ANZAHL_AUSLEIHEN, na.rm=TRUE)

#-------------------------------------------------------
# handling of missing values
#-------------------------------------------------------
# testing for missing values
is.na(csvData$Age)

# recoding
csvData[is.na(csvData$Age),"Age"] <- 99 
summary(csvData)

# .. with a mode
Mode <- function(x) {
	ux <- unique(x)
	ux[which.max(tabulate(match(x, ux)))]
}

summary(csvData)
csvData[is.na(csvData$Gender),"Gender"] <- Mode(csvData$Gender)
summary(csvData)

# removing entries with missing values
csvData[sample(x = c(1:nrow(csvData)), size = 5), "Age"] <- NA

datasetWithNoNAs <- na.omit(csvData)
summary(datasetWithNoNAs)
nrow(csvData)
nrow(datasetWithNoNAs)

# selecting entries with missing values
csvData[!complete.cases(csvData),]

#-------------------------------------------------------
# Plots
#-------------------------------------------------------
# scatter plot
plot(x = datasetWithNoNAs$Age, y = datasetWithNoNAs$ANZAHL_AUSLEIHEN)
plot(x = datasetWithNoNAs$Age, y = datasetWithNoNAs$ANZAHL_AUSLEIHEN, 
		col = "red", # colour 
		main = "first plot", # title
		xlab = "Age", ylab = "Anzahl Ausleihen")

# scatter plot matrix
plot(datasetWithNoNAs)

# histogram
zz <- rnorm(n = 1000, mean = 0, sd = 1)
hist(zz, breaks = 10) # !! see help - breaks is a suggestion here
hist(zz, breaks = quantile(zz, probs = c(0,seq(0.1,1,0.1))))

# box plots
boxplot(datasetWithNoNAs$Age)

boxplot(Age ~ Gender*Likes_Movie, # formula syntax in R 
		data = datasetWithNoNAs,
		col=(c("blue","red")))