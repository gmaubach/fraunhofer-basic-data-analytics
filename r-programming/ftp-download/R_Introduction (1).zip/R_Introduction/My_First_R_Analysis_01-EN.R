###############################################################################################################
## o Filename: 
##  My_First_R_Analysis_01-EN.R
## o Author: 
##  Roberto R�sler (11.04.2013)
## 
## o Description:
##	The first small analysis with decision trees
##
## o Versions:
## 01: ....
##
## o Maturity:
##
## o Source command to use 
##   source('.../My_First_R_Analysis_01-EN.R')
##
## o Last changed:
##
################################################################################################################
#
#

#-------------------------------------------------------
# load libraries and source files
#-------------------------------------------------------
# install.packages(c("rpart.plot","rpart"), dep = TRUE)
library(rpart)		# methods for calculating decision trees
library(rpart.plot)	#"better" methods for displaying decision trees

# function for displaying "nicer trees" uses rpart.plot)
heat.tree <- function(tree, low.is.green=FALSE, ...) {
	y <- tree$frame$yval
	if(low.is.green)
		y <- -y
	max <- max(y)
	min <- min(y)
	cols <- rainbow(99, end=.36)[
			ifelse(y > y[1], (y-y[1]) * (99-50) / (max-y[1]) + 50,
					(y-min) * (50-1) / (y[1]-min) + 1)]
	prp(tree, branch.col=cols, box.col=cols, ...)
}

# function for cross validation
cvRpart   <- function(data, idCol, targetCol, ignoreCol, k = 5, rc = rpart.control(cp = 0.01)) {
	N <- nrow(data) # number of records
	nameTarget <- names(data)[targetCol] # name of target variable
	nameID <- names(data)[idCol] # name of ID-column
	foldID <- (sample(1:N, N, replace = FALSE) %% k)+1 
	resultMatrix <- NULL
	for(i in 1:k){
		cat("Iter=",i,"...\n")
		
		trainData 	<- data[which(foldID != i),,drop=FALSE]
		testData 	<- data[which(foldID == i),,drop=FALSE]
		
		treeModel 	<- rpart(as.formula(paste(nameTarget," ~ .",sep="")), data = trainData[,-union(idCol,ignoreCol)], control = rc) # training function
		treePredict <- predict(treeModel, testData) # forecasting function
		
		resultMatrix <- rbind(resultMatrix, cbind(testData[,nameID], testData[,nameTarget], treePredict))
	}
	colnames(resultMatrix) <- c("ID","Y","Y_hat")
	
	# error calculation
	residuals <- resultMatrix[,2] - resultMatrix[,3]
	me <- mean(residuals)
	mae <- mean(abs(residuals))
	mre <- mean(abs(residuals/resultMatrix[,2]))
	rmse <- sqrt(mean(residuals^2))
	r2 <- cor(resultMatrix[,2],resultMatrix[,3])^2
	
	valCritVec <- c(me,mae,mre,rmse,r2)
	names(valCritVec) <- c("me","mae","mre","rmse","r2")
	
	return(list(cvResults = resultMatrix, valCrit = valCritVec))
}

#-------------------------------------------------------
# load data
#-------------------------------------------------------
movieDataTrain <- read.csv(file = "DATA/MLDATA_SAMPLE_10K_PREPARED_Train_2013-04-11.csv")
movieDataPredict <- read.csv(file = "DATA/MLDATA_SAMPLE_10K_PREPARED_Test_2013-04-11.csv")

#-------------------------------------------------------
# preprocess data
#-------------------------------------------------------

head(movieDataTrain)
summary(movieDataTrain)

#-------------------------------------------------------
# modeling
#-------------------------------------------------------
# calculation of tree
simpleDT <- rpart(RATING ~ ., # use all describing variables
		data = movieDataTrain[,-c(1,2)], # remove ID
		control=rpart.control(cp=.001, minsplit = 250) # parameters for the decision tree
)

#-------------------------------------------------------
# plot of results
#-------------------------------------------------------
# plotting the tree to the console
print(simpleDT) # or simply 'simpleDT'

# Plot of tree - version 1
png(paste('Graphics\\SimpleDT_',format(Sys.time(), "%Y-%m-%d"),'.png',sep=''), width = 2000, height = 1000)
plot(simpleDT, uniform=TRUE,
		main="Movie Recommendation")
text(simpleDT, use.n=TRUE, all=TRUE, cex=.8)
dev.off()

# Plot of tree - version 2 
png(paste('Graphics\\SimpleDT_Heat_',format(Sys.time(), "%Y-%m-%d"),'.png',sep=''), width = 2000, height = 1000)
heat.tree(simpleDT, main="Movie Recommendation", type = 4, extra = 101, faclen = 0, fallen.leaves=TRUE)
dev.off()

#-------------------------------------------------------
# validate results
#-------------------------------------------------------

## cross validation
cv <- cvRpart(data = movieDataTrain, idCol = 1, targetCol = 3, ignoreCol = 2, rc = rpart.control(cp=.001, minsplit = 250))
cv$valCrit # total indices

# display forecasts from the cross validation
indSample <- sample(1:nrow(cv$cvResults), size = 500)
plot(x = jitter(cv$cvResults[indSample,3], a = 0.05), y = jitter(cv$cvResults[indSample,2], a = 0.05),
		col=rgb(100,100,0,70, maxColorValue=255), pch=13,
		main = "CV Ergebnisse", xlab = "Y_hat", ylab = "Y")

## validation with additional data aka "Prognose"
predictions <- predict(object = simpleDT, newdata = movieDataPredict)
indSample <- sample(1:nrow(cv$cvResults), size = 500)
plot(x = jitter(movieDataPredict[indSample,"RATING"], a = 0.05), y = jitter(predictions[indSample], a = 0.05),
		col=rgb(100,100,0,70, maxColorValue=255), pch=13,
		main = "Prognoseergebnisse", xlab = "Prognose", ylab = "Rating")

## better plot?
# install.packages("hexbin", dep = TRUE)
require(hexbin)
binning <- hexbin(jitter(movieDataPredict$RATING, a = 0.05), jitter(predictions, a = 0.05))
plot(binning)

#-------------------------------------------------------
# save results
#-------------------------------------------------------
# save(file = ....)
