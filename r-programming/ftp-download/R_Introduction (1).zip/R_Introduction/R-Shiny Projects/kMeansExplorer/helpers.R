
tightSpread <- function(x, k=3, spread=0.1) {
  means  <- apply(x, 2, mean)
  ranges <- apply(x, 2, range)
  spans  <- (ranges[2,]-ranges[1,]) * spread
  deltas <- spans / (k-1)
                                   # rows, columns
  reps <- array(1:(k*ncol(x)), dim=c(k, ncol(x)))
  #reps <- c(1:(k*ncol(x)))
  #dim(reps) <- c(k, ncol)
    
  for (i in 1:k) {
    # Replace each row by correct vector of coordinates
    reps[i,] <- means - spans/2 + (i-1)*deltas
  }
  
  # Randomize the column order, independently for each column,
  # in order to have a more chaotic starting situation
  for(j in 1:ncol(x)) {
    reps[,j] <- reps[sample(k),j]
  }
  
  
  return(reps)
}

evenSpread <- function(x, k=3) {
  # Get the value range along each data dimension
  ranges <- apply(x, 2, range)
  deltas <- (ranges[2,]-ranges[1,]) / (k+1)
                                  # rows, columns
  reps <- array(1:(k*ncol(x)), dim=c(k, ncol(x)))
  
  for (i in 1:k) {
    # Replace each row by correct vector of coordinates
    reps[i,] <- ranges[1,] + i*deltas
  }
  
  # Randomize the column order, independently for each column,
  # in order to have a more chaotic starting situation
  reps <- reps[sample(k),]
  
  return(reps)
}
