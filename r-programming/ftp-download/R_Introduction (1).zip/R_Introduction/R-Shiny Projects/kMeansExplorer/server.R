
# This is the server logic for a Shiny web application.
# You can find out more about building applications with Shiny here:
# 
# http://www.rstudio.com/shiny/
#

# If you have loaded this as a project in RStudio, you can start this
# Shiny app simply by pressing on the "Run App" button at the top-right
# of the scrpt/source code view (this one).
#
# Otherwise, you can start it manually from the R console by doing:
#
## Adjust as required
#setwd("U:/DataScientist Schulungen/Supplemental Material/R Scripts")
#
## Start our shiny app - note the app name corresponds to the name of the
## folder holding the server.R and ui.R scripts forming the core of the app.
#runApp("kMeansExplorer")


library(shiny)
library(cluster)
source("helpers.R")

shinyServer(function(input, output) {
  
  data <- reactive({
    # Select data set to use
    x <- switch(input$data,
                "xclara" = xclara,
                "ruspini" = ruspini)
    return(x)
  })
  
  partition <- reactive({
    
    # Shorthand reference to input$k from ui.R
    k <- input$k
    
    x <- data()
    
    # Set up the initial cluster representatives
    # Always use the same RNG seed for this...
    set.seed(42)
    reps <- switch(input$seed.type,
                   "fk" = x[c(1:k),], # first k elements from data set
                   "es" = evenSpread(x, k),
                   "ts" = tightSpread(x, k, 0.1))
    
    # Generate cluster partition
    part <- kmeans(x,
                   centers=reps,
                   iter.max=input$iter,
                   nstart=1,
                   algorithm="MacQueen")
    return(part)
  })
   
  output$clusterPlot <- renderPlot({
   
    x <- data()
    part <- partition()
    
    plot(x, col=part$cluster+1)
    points(part$centers, col="black", pch=8)
    
  })
  
})
