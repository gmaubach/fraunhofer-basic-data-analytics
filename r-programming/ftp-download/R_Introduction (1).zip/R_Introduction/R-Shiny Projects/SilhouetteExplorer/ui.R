
# This is the user-interface definition of a Shiny web application.
# You can find out more about building applications with Shiny here:
# 
# http://www.rstudio.com/shiny/
#

library(shiny)

shinyUI(pageWithSidebar(
  
  # Application title
  headerPanel(h2("Silhouette Explorer")),
  
  # Sidebar with a slider input for number of clusters
  sidebarPanel(height = "400px",
    selectInput("data",
                "Data Set:",
                choices = list("ruspini", "xclara"),
                selected = 1),
    sliderInput("k",
                "Number of clusters:",
                min = 2,
                max = 10,
                value = 5),
    sliderInput("iter",
                "Number of iterations:",
                min = 1,
                max = 100,
                value = 10)
  ),
  
  # Show a plot of the generated distribution
  mainPanel(
    plotOutput(outputId = "clusterPlot",
               width = "800px",
               height = "800px"),
    
    plotOutput(outputId = "silhouettePlot")
  )
))
