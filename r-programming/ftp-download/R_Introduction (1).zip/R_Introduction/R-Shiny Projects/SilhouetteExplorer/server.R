
# This is the server logic for a Shiny web application.
# You can find out more about building applications with Shiny here:
# 
# http://www.rstudio.com/shiny/
#

library(shiny)
library(cluster)
source("helpers.R")

shinyServer(function(input, output) {
  
  data <- reactive({
    # Select data set to use
    x <- switch(input$data,
                "xclara" = xclara,
                "ruspini" = ruspini)
    return(x)
  })
  
  partition <- reactive({
    
    # Shorthand reference to input$k from ui.R
    k <- input$k
    
    # Generate cluster partition
    part <- pam(data(),
                k,
                diss=FALSE,
                metric="euclidean")#,
                #medoids=reps)
    return(part)
  })
   
  output$clusterPlot <- renderPlot({
    
    x <- data()
    part <- partition()
    
    plot(x, col=part$clustering+1)
    points(part$medoids, col="black", pch=8)
    
    col <- c(2:(length(part$id.med)+1))
    labels <- buildLegendLabels(length(part$id.med))
    
    legend(x = "topright", legend=labels, fill=col, border="black",
           text.col = "black", bg = "gray90")
    
    
  })
  
  output$silhouettePlot <- renderPlot({
    part <- partition()
    
    sil <- silhouette(part)
    plot(main="Silhouette Plot", sil)
         #sil, col = part$clustering+1)
  })
  
})
