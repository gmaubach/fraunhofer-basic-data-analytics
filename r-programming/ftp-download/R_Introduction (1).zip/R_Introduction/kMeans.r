#
# Copyright (c) Georg Fuchs / SupCon Fuchs 2014-2015
#
library(cluster)

# Definition of a custom function: the elbow criterion plot
# It tries clustering with different values for k and plots
# the sum of squares over all clusters for each k -- roughly,
# a measure of how "diluted" the clusters are.
# This plot will show a "bend" (elbow) at the ideal number of
# clusters, because using fewer clusters than that (smaller k)
# means force-joining elements into a single cluster that should
# be in separate groups, resulting in a rapid square sum increase

elbowplot <- function(data, maxk = 15, seed = 42) {
  wss <- (nrow(data)-1)*sum(apply(data,2,var))       # Pseudo-SSE value for k=1 (all objects in one cluster)
  for (i in 2:maxk) {
    set.seed(seed)                                   # Always select the same starting objects for kmeans
    #wss[i] <- sum(kmeans(data, centers=i)$withinss) # Partion score for k=i is sum over all i per-cluster SSE
    wss[i] <- kmeans(data, centers=i)$tot.withinss   # Same as above, built-in SSE of cluster partition object
  }
  # Plot result -- type "b" means both dots and lines
  plot(1:maxk, wss, type="b", xlab="Number of Clusters",ylab="Within groups sum of squares")
}



# These two data sets ("Xclara" and "ruspini") come packaged with the "cluster" package
# The data(...) command is a very handy shortcut to get these data loaded into an R session,
# without having to manually find and download the corresponding csv files before reading
# them in with read.csv(...)
data(xclara)
#data(ruspini)

# Creat an elbow plot for this data set
elbowplot(xclara, maxk=8)

# Apply kmeans clustering, using the first 3 rows of the data set as the initial seed
# We get returned a partition object that contains all information on the cluster partition
# centers defines the initial seeds (mediods) for the first assignment round of the algorithm
# iter.max controls the number of refinement rounds the algorithm is allowed to perform
part <- kmeans(xclara, centers=xclara[c(1:3),], iter.max=1)

# Scatter plot of the data points. Use "numbered standard colors" for the groups (col parameter) corresponding to the cluster number
plot(xclara, col=part$cluster)
# On the just generated plot, superimpose the selected mediods
points(part$centers, col="blue", pch=part$cluster)



# Task for you to try out:
# 1) Try to adjust the maximum number of iterations of the algorithm. What happens at very low (1, 2) iteration rounds?
# 2) Look at the documentation of the returned "part" object (using "?kmeans" and following the link). Try to understand what fields
#    of that object hold what type of information by displaying them (e.g., type "part$custer" in the console). Have a look at the
#    plot commands again and reason about what is actually drawn, and how.
# 3) Rewrite the script to use the ruspini data set instead. What kind of changes do you need to make besides changing the data variable name?
#    (Hint: have a look at the elbow and/or scatter plot)