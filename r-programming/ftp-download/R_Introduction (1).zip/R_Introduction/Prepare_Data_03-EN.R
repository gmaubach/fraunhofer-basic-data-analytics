###############################################################################################################
## o Filename: 
##  Prepare_Data_03-EN.R
## o Author: 
##  rroesler (18.04.2013)
## 
## o Description:
## Prepare MovieLens-data for regression examples
##
## o Input:
##
## o Output:
##
## o Example:
##
## o Versions:
## v02: preprocessing into test set and training set
## v03: saving of a record referencing the "Star Wars (1977)" movie
##
## o Maturity:
##
## o Source command to use 
##   source('S:/itdi/public/Statistik/Datamining-Repository/R/tools/TOOLS_Sparzaehler/Prepare_Data_01.R')
##
## o Last changed:
##
################################################################################################################
#
#

#-------------------------
# import data
#-------------------------
# Ratings
mldata <- read.table(file = "DATA/ml-100k/u.data", header = FALSE, sep = "\t", 
		col.names = c("userid", "itemid", "rating", "timestamp"))
summary(mldata)

# Userinfo
mluser <- read.table(file = "DATA/ml-100k/u.user", header = FALSE, sep = "|", 
		col.names = c("userid","age","gender","occupation","zipcode"))
summary(mluser)

# Filminfos
mlmovie <- read.table(file = "DATA/ml-100k/u.item", header = FALSE, sep = "|", 
		col.names = c("movieid","movietitle","releasedate","videoreleasedate","IMDbURL","unknown","Action",
				"Adventure","Animation","Childrens","Comedy","Crime","Documentary","Drama","Fantasy",
				"FilmNoir","Horror","Musical","Mystery","Romance","SciFi","Thriller","War","Western"),
		colClasses = c("numeric",rep("character",4),rep("numeric",19)), quote = "")
summary(mlmovie)
head(mlmovie)


# linking of all three records
mlall <- merge(x = mldata, y = mluser, by.x = "userid", by.y = "userid")
mlall <- merge(x = mlall, y = mlmovie, by.x = "itemid", by.y = "movieid")

# create a record for the analysis
yearAsInteger <- as.integer(substr(mlall$releasedate, 8, 11))

mlAnalysis <- data.frame(MOVIEID = mlall$itemid, MOVIETITLE = mlall$movietitle, RATING = mlall$rating, 
		AGE = cut(mlall$age, breaks = c(0,7,20,25,30,35,45,75)), GENDER = mlall$gender,
		mlall[,c(13:ncol(mlall))],
		RELEASE_YEAR = cut(yearAsInteger, breaks = c(min(yearAsInteger, na.rm = TRUE),quantile(yearAsInteger, probs=seq(0.2,0.8,0.2), na.rm = TRUE), max(yearAsInteger, na.rm=TRUE)), include.lowest = TRUE))

# select a sample
set.seed(1234)
indSample <- sample(1:nrow(mlAnalysis), size = 20000, replace = FALSE)

sampleDmlAnalysisTrain <- mlAnalysis[indSample[1:10000],,drop=FALSE]
sampleDmlAnalysisTest <- mlAnalysis[indSample[-(1:10000)],,drop=FALSE]

save(list = c("indSample","mlAnalysis","sampleDmlAnalysisTrain","sampleDmlAnalysisTest"), file = paste("DATA/MLDATA_PREPARED_",Sys.Date(),".RData",sep=""))

write.csv(sampleDmlAnalysisTrain, file = paste("DATA/MLDATA_SAMPLE_10K_PREPARED_Train_",Sys.Date(),".csv",sep=""), row.names = FALSE)
write.csv(sampleDmlAnalysisTest, file = paste("DATA/MLDATA_SAMPLE_10K_PREPARED_Test_",Sys.Date(),".csv",sep=""), row.names = FALSE)

## save data refering to movie XYZ
ratingTime <- as.POSIXct(mlall$timestamp, origin="1970-01-01", tz="UTC")

mlAnalysisClass <- data.frame(MOVIETITLE = mlall$movietitle, RATING = mlall$rating, 
		AGE = cut(mlall$age, breaks = c(0,7,20,25,30,35,45,75)), GENDER = mlall$gender,
		OCCUPATION = mlall$occupation, 
		HOUR_RATING = format(ratingTime,"%HH"), 
		DAY_OF_WEEK_RATING = weekdays(ratingTime),
		MONTH_RATING = months(ratingTime),
		YEAR_RATING = as.numeric(format(ratingTime,"%Y"))
		)
mlAnalysisScream <- subset(mlAnalysisClass, MOVIETITLE == "Scream (1996)")
write.csv(mlAnalysisScream, file = paste("DATA/MLDATA_Scream_CLASSIFICATION_PREPARED_",Sys.Date(),".csv",sep=""), row.names = FALSE)

## create a record for clustering
library(plyr) # library for transforming records
mlAnalysisCluster <- ddply(mlall[,-c(1,3:12)], .(userid), colSums)
write.csv(mlAnalysisCluster, file = paste("DATA/MLDATA_CLUSTERING_PREPARED_",Sys.Date(),".csv",sep=""), row.names = FALSE)